package kite.amibee.com.netstore.model.pojo.orders;

import com.google.gson.annotations.SerializedName;

public class CreatedDate {

}
