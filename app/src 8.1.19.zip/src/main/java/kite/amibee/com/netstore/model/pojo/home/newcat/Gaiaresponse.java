package kite.amibee.com.netstore.model.pojo.home.newcat;

import com.google.gson.annotations.SerializedName;

import java.util.List;

import kite.amibee.com.netstore.model.pojo.home.newcat.NewCatResponse;

public class Gaiaresponse {
    @SerializedName("categoryList")
    public List<NewCatResponse> categoryList;
    @SerializedName("1")
    public List<NewCatResponse> responses_1;
    @SerializedName("2")
    public List<NewCatResponse> responses_2;
    @SerializedName("3")
    public List<NewCatResponse> responses_3;
    @SerializedName("4")
    public List<NewCatResponse> responses_4;
    @SerializedName("5")
    public List<NewCatResponse> responses_5;




}
