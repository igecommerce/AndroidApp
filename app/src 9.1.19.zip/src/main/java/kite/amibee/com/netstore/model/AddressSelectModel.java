package kite.amibee.com.netstore.model;

public class AddressSelectModel{
    public String mName;
    public AddressSelectModel(String name){
        mName = name;
    }
}
