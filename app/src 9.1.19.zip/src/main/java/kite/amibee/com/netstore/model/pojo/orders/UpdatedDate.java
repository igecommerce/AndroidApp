package kite.amibee.com.netstore.model.pojo.orders;

public class UpdatedDate {
}
